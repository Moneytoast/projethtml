<?php include 'connect.php';
?>
<!DOCTYPE html>
<html>
<head>
		<meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1.0">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="style.css" rel="stylesheet">
		<title>Hockey</title>
		<script src="js/jquery-3.1.0.js"></script>
		<script  type="text/javascript">
		$(document).ready(function()
		{
			$("#equipe").on('change', function()
			{
					var id=$(this).val();
					var dataString = 'id=' + id;
					$("#joueur").find('option').remove();
					$("#table").find('table').remove();
					$.ajax
					({
						type: "POST",
						url: "getEtat.php",
						data: dataString,
						cache: false,
						success: function(html)
						{
							$("#joueur").html(html);
						}
					});
				
			});
			$("#joueur").on('change', function()
			{
					var id=$(this).val();
					var dataString = 'id=' + id;
					$("#table").find('table').remove();
					$.ajax
					({
						type: "POST",
						url: "getStats.php",
						data: dataString,
						cache: false,
						success: function(html)
						{
							$("#stats").html(html);
						}
					});
				
			});
		});
		</script>
</head>
<body>
	<h1 align="center">Statistiques des joueurs d'hockey de la LNH</h1> 
		<div class="container" align="center">
			<div class="row">
				<div class="col-md-4 col-md-offset-4">
					<label>Equipe :</label>
					<select id="equipe" class="form-control">
					<option selected="selected">--Choisir une equipe--</option>
					<?php 	
						$stmt = $link->prepare("SELECT * FROM equipe");
						$stmt->execute();
						while($row=$stmt->fetch(PDO::FETCH_ASSOC)) {
					?>
							<option value="<?php echo $row['EquipeID']; ?>"><?php echo $row['nomEquipe']; ?></option>
						<?php 
						}
						?>
						</select>
					</div>
				</div>
				<div class="row">
					<div class="col-md-4 col-md-offset-4">
						<label>Joueur :</label>
						<select id="joueur" class="form-control">
						<option selected="selected">--Choisir un joueur--</option>
						</select>
					</div>
				</div>
				<div id="stats">
	 
	</div>
				
			</div>
</body>
</html>
