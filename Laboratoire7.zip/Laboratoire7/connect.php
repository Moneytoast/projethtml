<?php

$db_host = "localhost";
$db_username = "root";
$db_password = "";
$db_name = "hockey";

try {
	$link = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8",$db_username,
	'');
	$link->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(PDOException $e){
	echo "Connection impossible" . $e->getMessage();
}
?>