<?php  
include('connect.php');

	if($_POST['id']) {
		$id=$_POST['id'];
		
		$stmt = $link->prepare("SELECT * FROM stats WHERE JoueurID=:id");
		$stmt->execute(array(':id' => $id));
		?>
		<div id="table" class="col-md-4 col-md-offset-4">
		<table style="width:100%">
		<tr>
			<th>Position</th>
			<th>DDN</th>
			<th>Grandeur</th>
			<th>Poid</th>
			</tr>
			<tr>
		<?php
		while($row=$stmt->fetch(PDO::FETCH_ASSOC)) {
		?>
		<th><?php echo $row['POSITION']; ?></th>
		<th><?php echo $row['DDN']; ?></th>
		<th><?php echo $row['GRANDEUR']; ?></th>
		<th><?php echo $row['POID']; ?></th>
		<?php 
		}
		?>
		</tr>
		</table>
		</div>
	<?php
	}
	?>