<?php  
include('connect.php');

	if($_POST['id']) {
		$id=$_POST['id'];
		
		$stmt = $link->prepare("SELECT * FROM joueur WHERE EquipeID=:id");
		$stmt->execute(array(':id' => $id));
		?>
		<option selected="selected">--Choisir un joueur--</option>
		<?php
		while($row=$stmt->fetch(PDO::FETCH_ASSOC)) {
		?>
		<option value="<?php echo $row['JoueurID']; ?>"><?php echo $row['nomJoueur']; ?></option>
		<?php 
		}
		?>
		
	<?php
	}
	?>



